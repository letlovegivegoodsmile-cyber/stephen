// ========== STATE ==========
let currentLang = 'fr';
const tourDatesFR = [
  { date: '3 Nov 2026', venue: 'Annecy', hall: 'Arcadium', status: 'ok', statusFR: 'Disponible', statusEN: 'Available' },
  { date: '5 Nov 2026', venue: 'Saint-Dizier', hall: 'Les 3 Scènes', status: 'ok', statusFR: 'Disponible', statusEN: 'Available' },
  { date: '7 Nov 2026', venue: 'Nantes', hall: 'Le Laps', status: 'ok', statusFR: 'Disponible', statusEN: 'Available' },
  { date: '10 Nov 2026', venue: 'Bordeaux', hall: 'Théâtre Fémina', status: 'ok', statusFR: 'Disponible', statusEN: 'Available' },
  { date: '16 Nov 2026', venue: 'Joué-Lès-Tours', hall: 'Espace Malraux', status: 'ok', statusFR: 'Disponible', statusEN: 'Available' },
  { date: '17 Nov 2026', venue: 'Limoges', hall: 'Opéra de Limoges', status: 'ok', statusFR: 'Disponible', statusEN: 'Available' },
  { date: '21 Nov 2026', venue: 'Amiens', hall: 'Cirque Jules Verne', status: 'ok', statusFR: 'Disponible', statusEN: 'Available' },
  { date: '26 Nov 2026', venue: 'Coulommiers', hall: 'La Sucrerie', status: 'ok', statusFR: 'Disponible', statusEN: 'Available' },
  { date: '19 Fév 2027', venue: 'Saint-Rémy-de-Provence', hall: 'Alpilium', status: 'ok', statusFR: 'Disponible', statusEN: 'Available' },
  { date: '11 Mar 2027', venue: 'Yutz', hall: 'L’Amphy', status: 'ok', statusFR: 'Disponible', statusEN: 'Available' },
  { date: '19 Mar 2027', venue: 'Vias', hall: 'Théâtre de l’Ardaillon', status: 'ok', statusFR: 'Disponible', statusEN: 'Available' }
];
const songbookDates = [
  { date: '1 Mar 2027', venue: 'Zürich', hall: 'Opernhaus Zürich · Premiere', status: 'prem', statusFR: 'Première', statusEN: 'Premiere' },
  { date: '30 Mar 2027', venue: 'Luzern', hall: 'KKL Luzern', status: 'ok', statusFR: 'Billets', statusEN: 'Tickets' },
  { date: '31 Mar 2027', venue: 'Basel', hall: 'Stadtcasino Basel', status: 'ok', statusFR: 'Billets', statusEN: 'Tickets' },
  { date: '1–2 Avr 2027', venue: 'Zürich', hall: 'Theater 11', status: 'ok', statusFR: 'Billets', statusEN: 'Tickets' },
  { date: '5 Avr 2027', venue: 'Thun', hall: 'Schadausaal KKThun', status: 'ok', statusFR: 'Billets', statusEN: 'Tickets' },
  { date: '6 Avr 2027', venue: 'Rapperswil', hall: 'ENTRA Rapperswil', status: 'ok', statusFR: 'Billets', statusEN: 'Tickets' },
  { date: '9 Avr 2027', venue: 'Bern', hall: 'Kursaal Bern', status: 'ok', statusFR: 'Billets', statusEN: 'Tickets' },
  { date: '11 Avr 2027', venue: 'Amriswil', hall: 'Pentorama Amriswil', status: 'ok', statusFR: 'Billets', statusEN: 'Tickets' },
  { date: '12 Avr 2027', venue: 'Suhr', hall: 'Bärenmatte Suhr', status: 'ok', statusFR: 'Billets', statusEN: 'Tickets' },
  { date: '14 Avr 2027', venue: 'St. Gallen', hall: 'Tonhalle St. Gallen', status: 'ok', statusFR: 'Billets', statusEN: 'Tickets' }
];

// Demo customer bookings
let bookings = [
  { id: 1, client: 'client', date: '2026-11-05', venue: 'Annecy — Arcadium', status: 'confirmed' },
  { id: 2, client: 'client', date: '2026-11-10', venue: 'Bordeaux — Théâtre Fémina', status: 'pending' }
];

let currentUser = null;
let bufferInterval = null;

// ========== LANGUAGE ==========
function toggleLanguage() {
  currentLang = currentLang === 'fr' ? 'en' : 'fr';
  document.getElementById('langFR').className = currentLang === 'fr' ? 'active' : 'inactive';
  document.getElementById('langEN').className = currentLang === 'en' ? 'active' : 'inactive';
  document.documentElement.lang = currentLang === 'fr' ? 'fr' : 'en';
  document.querySelectorAll('[data-fr][data-en]').forEach(el => {
    el.textContent = currentLang === 'fr' ? el.dataset.fr : el.dataset.en;
  });
  // Update buttons
  document.getElementById('loginBtn').textContent = currentLang === 'fr' ? 'Connexion' : 'Login';
  renderTourDates();
  renderBookings();
  renderAdminBookings();
  if (currentUser) updateDashboardLang();
}

// ========== TOUR RENDERING ==========
function renderTourDates() {
  const fr = currentLang === 'fr';
  const containerFR = document.getElementById('tourDatesFR');
  containerFR.innerHTML = tourDatesFR.map(d => `
    <div class="date-row">
      <div class="d">${d.date}</div>
      <div class="v"><strong>${d.venue}</strong><span>${d.hall}</span></div>
      <span class="badge ok">${fr ? d.statusFR : d.statusEN}</span>
    </div>
  `).join('');

  const containerSB = document.getElementById('songbookDates');
  containerSB.innerHTML = songbookDates.map(d => `
    <div class="date-row">
      <div class="d">${d.date}</div>
      <div class="v"><strong>${d.venue}</strong><span>${d.hall}</span></div>
      <span class="badge ${d.status}">${fr ? d.statusFR : d.statusEN}</span>
    </div>
  `).join('');
}

// ========== MODALS ==========
function openLogin() {
  document.getElementById('loginModal').classList.add('active');
}
function openAdminLogin() {
  document.getElementById('adminModal').classList.add('active');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('active');
}
function openBookingForm() {
  document.getElementById('bookingModal').classList.add('active');
}

// ========== LOGIN ==========
function handleLogin() {
  const user = document.getElementById('loginUser').value.trim();
  const pass = document.getElementById('loginPass').value.trim();
  if (user === 'client' && pass === 'client123') {
    currentUser = user;
    closeModal('loginModal');
    openDashboard();
  } else {
    alert(currentLang === 'fr' ? 'Identifiants incorrects.' : 'Invalid credentials.');
  }
}

function handleAdminLogin() {
  const user = document.getElementById('adminUser').value.trim();
  const pass = document.getElementById('adminPass').value.trim();
  if (user === 'admin' && pass === 'admin123') {
    closeModal('adminModal');
    openAdminPanel();
  } else {
    alert(currentLang === 'fr' ? 'Identifiants admin incorrects.' : 'Invalid admin credentials.');
  }
}

// ========== DASHBOARD WITH BUFFERING ==========
function openDashboard() {
  const overlay = document.getElementById('dashboardOverlay');
  const buffer = document.getElementById('bufferScreen');
  const panel = document.getElementById('dashboardPanel');
  overlay.classList.add('active');
  buffer.classList.add('active');
  panel.classList.remove('active');

  // Reset buffer
  let count = 7;
  document.getElementById('bufferCountdown').textContent = count;
  document.getElementById('bufferFill').style.width = '0%';

  clearInterval(bufferInterval);
  bufferInterval = setInterval(() => {
    count--;
    document.getElementById('bufferCountdown').textContent = count;
    document.getElementById('bufferFill').style.width = ((7 - count) / 7 * 100) + '%';
    if (count <= 0) {
      clearInterval(bufferInterval);
      buffer.classList.remove('active');
      panel.classList.add('active');
      renderBookings();
      updateDashboardLang();
      document.getElementById('dashUserName').textContent = currentLang === 'fr' ? `Bonjour, ${currentUser}` : `Hello, ${currentUser}`;
    }
  }, 1000);
}

function closeDashboard() {
  document.getElementById('dashboardOverlay').classList.remove('active');
  currentUser = null;
  clearInterval(bufferInterval);
}

function updateDashboardLang() {
  const fr = currentLang === 'fr';
  document.getElementById('dashWelcome').textContent = fr ? 'Bienvenue' : 'Welcome';
  // Update data-fr/data-en elements inside dashboard if any
  document.querySelectorAll('#dashboardPanel [data-fr][data-en]').forEach(el => {
    el.textContent = fr ? el.dataset.fr : el.dataset.en;
  });
  renderBookings();
}

// ========== BOOKINGS RENDERING ==========
function renderBookings() {
  const userBookings = bookings.filter(b => b.client === currentUser);
  const container = document.getElementById('dashBookings');
  if (!container) return;
  const fr = currentLang === 'fr';
  if (userBookings.length === 0) {
    container.innerHTML = `<div style="padding:1.5rem; color:var(--muted); font-size:0.9rem;">${fr ? 'Aucune réservation pour le moment.' : 'No bookings yet.'}</div>`;
    return;
  }
  container.innerHTML = `
    <div class="booking-header">
      <span>${fr ? 'Date' : 'Date'}</span>
      <span>${fr ? 'Lieu' : 'Venue'}</span>
      <span>${fr ? 'Statut' : 'Status'}</span>
      <span></span>
    </div>
    ${userBookings.map(b => `
      <div class="booking-row">
        <div class="b-date">${b.date}</div>
        <div class="b-venue">${b.venue}</div>
        <span class="b-status ${b.status}">${b.status === 'confirmed' ? (fr ? 'Confirmé' : 'Confirmed') : (fr ? 'En attente' : 'Pending')}</span>
        <div></div>
      </div>
    `).join('')}
  `;
}

// ========== SUBMIT BOOKING ==========
function submitBooking() {
  const date = document.getElementById('bookingDate').value;
  const venue = document.getElementById('bookingVenue').value.trim();
  if (!date || !venue) {
    alert(currentLang === 'fr' ? 'Veuillez remplir tous les champs.' : 'Please fill all fields.');
    return;
  }
  const newBooking = {
    id: bookings.length + 1,
    client: currentUser,
    date: date,
    venue: venue,
    status: 'pending'
  };
  bookings.push(newBooking);
  closeModal('bookingModal');
  renderBookings();
  document.getElementById('bookingDate').value = '';
  document.getElementById('bookingVenue').value = '';
  alert(currentLang === 'fr' ? 'Réservation ajoutée !' : 'Booking added!');
}

// ========== ADMIN PANEL ==========
function openAdminPanel() {
  document.getElementById('adminPanelOverlay').classList.add('active');
  document.getElementById('adminPanel').classList.add('active');
  renderAdminBookings();
}

function closeAdminPanel() {
  document.getElementById('adminPanelOverlay').classList.remove('active');
  document.getElementById('adminPanel').classList.remove('active');
}

function renderAdminBookings() {
  const tbody = document.getElementById('adminBookingsTable');
  if (!tbody) return;
  const fr = currentLang === 'fr';
  tbody.innerHTML = bookings.map(b => `
    <tr>
      <td>${b.client}</td>
      <td>${b.date}</td>
      <td>${b.venue}</td>
      <td>
        <select class="status-select" onchange="updateBookingStatus(${b.id}, this.value)">
          <option value="pending" ${b.status === 'pending' ? 'selected' : ''}>${fr ? 'En attente' : 'Pending'}</option>
          <option value="confirmed" ${b.status === 'confirmed' ? 'selected' : ''}>${fr ? 'Confirmé' : 'Confirmed'}</option>
        </select>
      </td>
      <td>
        <div class="admin-actions">
          <button class="danger" onclick="deleteBooking(${b.id})">${fr ? 'Supprimer' : 'Delete'}</button>
        </div>
      </td>
    </tr>
  `).join('');
}

function updateBookingStatus(id, status) {
  const b = bookings.find(x => x.id === id);
  if (b) b.status = status;
  renderBookings();
  renderAdminBookings();
}

function deleteBooking(id) {
  if (confirm(currentLang === 'fr' ? 'Supprimer cette réservation ?' : 'Delete this booking?')) {
    bookings = bookings.filter(b => b.id !== id);
    renderBookings();
    renderAdminBookings();
  }
}

// ========== INIT ==========
document.addEventListener('DOMContentLoaded', () => {
  renderTourDates();
  // Set default date for booking
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('bookingDate').setAttribute('min', today);
});
